<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel=icon href="https://www.hashmicro.com/inc/favicon.ico" type=image/x-icon />
    <title>List-Page Hashmicro ADS</title>
</head>
<body>

<style>a{font-size:25px; display:inline-block;margin-bottom:10px}</style>

    <ol>
        <li>
            <a href="./software-agriculture">software-agriculture</a>
        </li>
        <li>
            <a href="./software-akuntansi">software-akuntansi</a>
        </li>
        <li>
            <a href="./software-erp">software-erp</a>
        </li>
        <li>
            <a href="./software-fnb">software-fnb</a>
        </li>
        <li>
            <a href="./software-inventory">software-inventory</a>
        </li>
        <li>
            <a href="./software-konstruksi">software-kontruksi</a>
        </li>
        <li>
            <a href="./software-manufaktur">software-manufaktur</a>
        </li>
        <li>
            <a href="./software-mining">Software-mining</a>
        </li>
        <li>
            <a href="./software-procurement">Software-procurement</a>
        </li>
        <li>
            <a href="./software-retail">Software-retail</a>
        </li>
        <li>
            <a href="./software-trading">Software-trading</a>
        </li>
        <li>
            <a href="./software-warehouse">Software-warehouse</a>
        </li>
    </ol>
</body>
</html>