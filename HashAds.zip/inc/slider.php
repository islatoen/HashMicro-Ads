<div class="container wrap-track">
            <div class="row">
                <div>
                <div class="aos-init aos-animate" data-aos="fade-right" data-aos-duration="500">
                    <!-- col-lg-1 -->
                    <p class="p-dipercaya" style="color:#888888 ;">
                        <strong>Dipercaya Oleh:</strong>
                    </p>
                </div>
                <div class="col-lg-12 aos-init aos-animate" data-aos="fade-up" data-aos-duration="500">
                    <div class="slider mx-auto mx-md-0 slider-4">
                        <div class="slide-track">

                            <div class="slide">
                                 <img src="https://mitrahash.com/assets/img/brand-logo/bank-mega.webp"  style="width:80%;padding-top:2rem;" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/logo_0001_wendys-hover.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/pertamina.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/rucika.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/matahari-departemen.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://www.hashmicro.com/assets/images/Logo/ID/logo_asli/marimas.webp" style="width:85%;padding-top:1.5rem;" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/yokohama.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/astra-infra.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/ichiban-sushi.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/trans-f-b.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/tata.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/bank-mega.webp"  style="width:80%;padding-top:2rem;" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img data-cfsrc="https://mitrahash.com/assets/img/brand-logo/logo_0001_wendys-hover.webp" height="100" width="50" alt="" src="https://mitrahash.com/assets/img/brand-logo/logo_0001_wendys-hover.webp">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/pertamina.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/rucika.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/matahari-departemen.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                               <img src="https://www.hashmicro.com/assets/images/Logo/ID/logo_asli/marimas.webp" style="width:85%;padding-top:1.5rem;" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/yokohama.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/astra-infra.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/ichiban-sushi.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/trans-f-b.webp" height="100" width="50" alt="">
                            </div>

                            <div class="slide">
                                <img src="https://mitrahash.com/assets/img/brand-logo/tata.webp" height="100" width="50" alt="">
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>