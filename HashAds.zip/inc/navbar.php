<nav class="navbar navbar-expand-lg navbar-light fixed-top" style="background-color:#F7F7F7 ;">
        <div class="container con-nav">
            <a class="navbar-brand ms-0" href="#"><img class="img-brand" src="./Assets/hashmicro-red.svg"></a>
            <div class="d-flex gap-3">
                <a class="a-hidden" href="#"><button type="button" class="hidden-button custom-hidden" data-bs-target="#exampleModal"
                    data-bs-toggle="modal">Demo Gratis</button></a>
                <button class="navbar-toggler1" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>               
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto  me-4 row align-items-left">
                    <li class="nav-item navi1 col-4">
                        <a class="navigasi row" href="tel:+622150861560">
                            <i class="fa-solid fa-phone col-3 iconnav1"></i>
                            <p id="navtext" class="col-9" style="text-align: left;"><span>Hubungi
                                    Kami</span><br><b>021 5086 1560</b></p>
                        </a>
                    </li>
                    <li class="nav-item navi1 col-5">
                        <a class="navigasi row" href="mailto:halo@hashmicro.com">
                            <i class="fa-solid fa-envelope col-3 iconnav"></i>
                            <p id="navtext" class="col-9" style="text-align: left;"><span>Email Sekarang
                                </span><br><b>halo@hashmicro.com</b></p>
                        </a>
                    </li>
                    <li class="nav-item navi1 col-3">
                        <a class="navigasi row" href="https://wa.me/+628111171167">
                            <i class="fa-brands fa-whatsapp iconnav2 col-3"></i>
                            <p id="navtext" class="col-9" style="text-align: left;">
                                <span>Whatsapp</span><br><b>HashMicro</b>
                            </p>
                        </a>
                    </li>
                </ul>
                <a href="#"><button type="button" class="buttonDemo custom-demo ms-auto " data-bs-target="#exampleModal"
                        data-bs-toggle="modal">Demo Gratis</button></a>
            </div>
        </div>
    </nav>